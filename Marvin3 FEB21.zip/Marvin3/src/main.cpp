//242B Created by M.Gublo and L.Borkowski
#include "main.h"
#include "okapi/api.hpp"
using namespace okapi;

//DEFINITIONS
Controller master;
ControllerButton runAutoButton(ControllerDigital::X);
ControllerButton intakeIN(ControllerDigital::R1);
ControllerButton intakeOUT(ControllerDigital::R2);
ControllerButton liftUP(ControllerDigital::L1);
ControllerButton liftDOWN(ControllerDigital::L2);
ControllerButton trayFWD(ControllerDigital::Y);
ControllerButton trayBWD(ControllerDigital::right);

ChassisControllerBuilder* chassisbuild = new ChassisControllerBuilder();

Motor left_drv(10);
Motor right_drv(-1);
Motor left_drv_back(9);
Motor right_drv_back(-3);
Motor tray(12);
Motor armLift(-13);
Motor left_intake(20);
Motor right_intake(-11);

int startingPos = 0;

auto drive = chassisbuild -> withMotors(
		{left_drv,left_drv_back},
		{right_drv,right_drv_back}
		)
	.withDimensions(AbstractMotor::gearset::green, {{3_in, 7.5_in}, imev5GreenTPR})
	.withOdometry()
  .buildOdometry();

auto armController = AsyncPosControllerBuilder()
	 .withMotor(armLift) // lift motor port 3
	 .build();
auto trayController = AsyncPosControllerBuilder()
	 	 .withMotor(tray) // lift motor port 3
	 	 .build();
auto profileController = AsyncMotionProfileControllerBuilder()
	 .withLimits({1.0, 2.0, 10.0})
	 .withOutput(drive)
	 .buildMotionProfileController();


//------------------------------------------------------------------------------
/**
 * A callback function for LLEMU's center button.
 *
 * When this callback is fired, it will toggle line 2 of the LCD text between
 * "I was pressed!" and nothing.
 */
void on_center_button() {
	static bool pressed = false;
	pressed = !pressed;
	if (pressed) {
		startingPos = 1;
		pros::lcd::clear_line(2);
		pros::lcd::set_text(2, "RED");
	} else {
		startingPos = 0;
		pros::lcd::clear_line(2);
	}
}

void on_left_button() {
	static bool pressed = false;
	pressed = !pressed;
	if (pressed) {
		startingPos = 2;
		pros::lcd::clear_line(2);
		pros::lcd::set_text(2, "BLUE");
	} else {
		startingPos = 0;
		pros::lcd::clear_line(2);
	}
}

void on_right_button() {
	static bool pressed = false;
	pressed = !pressed;
	if (pressed) {
		startingPos = 3;
		pros::lcd::clear_line(2);
		pros::lcd::set_text(2, "CUBE PUSH");
	} else {
		startingPos = 0;
		pros::lcd::clear_line(2);
	}
}

/**
 * Runs initialization code. This occurs as soon as the program is started.
 */
void initialize() {
	pros::lcd::initialize();
	pros::lcd::set_text(1, "M A R V I N");
	pros::lcd::register_btn1_cb(on_center_button);
	pros::lcd::register_btn0_cb(on_left_button);
	pros::lcd::register_btn2_cb(on_right_button);
	pros::lcd::print(5, "%d", startingPos);

	left_intake.setBrakeMode(AbstractMotor::brakeMode::hold);
	right_intake.setBrakeMode(AbstractMotor::brakeMode::hold);
	armLift.setBrakeMode(AbstractMotor::brakeMode::hold);
	tray.setBrakeMode(AbstractMotor::brakeMode::hold);
}

/**
 * Runs while the robot is in the disabled state of Field Management System or
 * the VEX Competition Switch, following either autonomous or opcontrol. When
 * the robot is enabled, this task will exit.
 */
void disabled() {}

/**
 * Runs after initialize(), and before autonomous when connected to the Field
 * Management System or the VEX Competition Switch. This is intended for
 * competition-specific initialization routines, such as an autonomous selector
 * on the LCD.
 *
 * This task will exit when the robot is enabled and autonomous or opcontrol
 * starts.
 */
void competition_initialize() {}

/**
 * Runs the user autonomous code. This function will be started in its own task
 * with the default priority and stack size whenever the robot is enabled via
 * the Field Management System or the VEX Competition Switch in the autonomous
 * mode. Alternatively, this function may be called in initialize or opcontrol
 * for non-competition testing purposes.
 *
 * If the robot is disabled or communications is lost, the autonomous task
 * will be stopped. Re-enabling the robot will restart the task, not re-start it
 * from where it left off.
 */
void autonomous() {
	drive->setMaxVelocity(100);
	if (startingPos == 1 or startingPos == 2) {

		//start intakes
		left_intake.moveVelocity(100);
		right_intake.moveVelocity(100);

		//move toward first cube and sucks it up
		drive->moveDistance(24_in);

		//stop intake
		left_intake.moveVelocity(0);
		right_intake.moveVelocity(0);

		//makes it either red or blue depending on button pressed, turns toward second cube
		if(startingPos == 1) { //Red
			drive ->turnAngle(130_deg);
		} else if(startingPos == 2) { //Blue
			drive ->turnAngle(-130_deg);
		}

		//start intakes again
		left_intake.moveVelocity(100);
		right_intake.moveVelocity(100);
		//move toward second cube and suck it up
		drive->moveDistance(29_in);

		//turn toward zone
		if(startingPos == 1) { //Red
			drive ->turnAngle(-270_deg);
		} else if(startingPos == 2) { //Blue
			drive ->turnAngle(270_deg);
		}

		//move into zone
		drive ->moveDistance(30_in);

		//set down one cube
		left_intake.moveVelocity(-100);
		right_intake.moveVelocity(-100);
		pros::delay(850);
		left_intake.moveVelocity(0);
		right_intake.moveVelocity(0);

		//move tray
		tray.moveVelocity(100);
		pros::delay(1900);
		tray.moveVelocity(0);

		pros::delay(1000);
		//finish spitting out stack
		left_intake.moveVelocity(-100);
		right_intake.moveVelocity(-100);

		left_drv.moveVelocity(80);
		right_drv.moveVelocity(80);
		left_drv_back.moveVelocity(80);
		right_drv_back.moveVelocity(80);
		pros::delay(666);
		left_drv.moveVelocity(0);
		right_drv.moveVelocity(0);
		left_drv_back.moveVelocity(0);
		right_drv_back.moveVelocity(0);

		//drive ->moveDistance(1_in);
		pros::delay(500);
		//back away
		left_drv.moveVelocity(-100);
		right_drv.moveVelocity(-100);
		pros::delay(1000);
		left_drv.moveVelocity(0);
		right_drv.moveVelocity(0);

	} else if (startingPos == 3) { //CUBE PUSH
		//move backward into zone
		left_drv.moveVelocity(-75);
		right_drv.moveVelocity(-75);
		pros::delay(2500);
		left_drv.moveVelocity(0);
		right_drv.moveVelocity(0);
		pros::delay(10);
		//mvoe forward out of zone
		drive->moveDistance(18_in);
		pros::delay(100);
		//raise tray to deploy
		tray.moveVelocity(100);
		pros::delay(300);
		tray.moveVelocity(0);
		//lift arms to deploy
		armLift.moveVelocity(100);
		pros::delay(1300);
		left_intake.moveVelocity(-100);
		right_intake.moveVelocity(-100);
		pros::delay(5000);
		left_intake.moveVelocity(0);
		right_intake.moveVelocity(0);
		armLift.moveVelocity(-100);
		pros::delay(1300);
		armLift.moveVelocity(0);

	}
}

 //X buttion to run autonomous
 void xbttn() {
 	// Run the test autonomous routine if we press the button
 	if (runAutoButton.changedToPressed()) {
 		autonomous();
 	}
}

//drive function
void chassis_drive() {
	drive->getModel()->tank(master.getAnalog(ControllerAnalog::leftY),
													master.getAnalog(ControllerAnalog::rightY));
	// drive->getModel()->arcade(master.getAnalog(ControllerAnalog::leftY),
	// 						 	         master.getAnalog(ControllerAnalog::leftX));
}

//intake function
void intake_op() {
	if (intakeIN.isPressed()) {
		left_intake.moveVelocity(125);
		right_intake.moveVelocity(125);
	} else if (intakeOUT.isPressed()) {
		left_intake.moveVelocity(-100);
		right_intake.moveVelocity(-100);
	} else {
		left_intake.moveVelocity(0);
		right_intake.moveVelocity(0);
	}
}

//lift function
void lift_op() {
	if (liftUP.isPressed()) {
		armLift.moveVelocity(100);
	} else if (liftDOWN.isPressed()) {
		armLift.moveVelocity(-120);
	} else {
		armLift.moveVelocity(0);
	}
}

//tray function
void tray_op() {
	if (trayBWD.isPressed()) {
		tray.moveVelocity(-80);
	} else if (trayFWD.isPressed()) {
		tray.moveVelocity(80);
	} else {
		tray.moveVelocity(0);
	}
}
/**
 * Runs the operator control code. This function will be started in its own task
 * with the default priority and stack size whenever the robot is enabled via
 * the Field Management System or the VEX Competition Switch in the operator
 * control mode.
 *
 * If no competition control is connected, this function will run immediately
 * following initialize().
 *
 * If the robot is disabled or communications is lost, the
 * operator control task will be stopped. Re-enabling the robot will restart the
 * task, not resume it from where it left off.
 */
void opcontrol() {

		drive->setMaxVelocity(200);

	while (true) {
		//xbttn();
		chassis_drive();
		intake_op();
		lift_op();
		tray_op();
		xbttn();
		pros::lcd::print(0, "%d %d %d", (pros::lcd::read_buttons() & LCD_BTN_LEFT) >> 2,
		                 (pros::lcd::read_buttons() & LCD_BTN_CENTER) >> 1,
		                 (pros::lcd::read_buttons() & LCD_BTN_RIGHT) >> 0);

		//pros::lcd::print(4, "%d", shaftEncoder.get());
		//pros::lcd::print(5, "%d", shaftEncoder.controllerGet());

		pros::delay(10);
	}
}
