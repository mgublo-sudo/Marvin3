#include "main.h"
#include "okapi/api.hpp"

using namespace okapi;

Controller master;
ControllerButton runAutoButton(ControllerDigital::X);
ControllerButton intakeIN(ControllerDigital::R1);
ControllerButton intakeOUT(ControllerDigital::R2);
ControllerButton liftUP(ControllerDigital::L1);
ControllerButton liftDOWN(ControllerDigital::L2);
ControllerButton trayFWD(ControllerDigital::Y);
ControllerButton trayBWD(ControllerDigital::right);

Motor left_drv(10);
Motor right_drv(-1);
Motor tray(12);
Motor armLift(-13);
Motor left_intake(20);
Motor right_intake(-11);

auto drive = ChassisControllerBuilder()
	.withMotors(left_drv,right_drv)
	.withDimensions(AbstractMotor::gearset::green, {{3_in, 7.5_in}, imev5GreenTPR})
	.withOdometry()
  .buildOdometry();


auto profileController = AsyncMotionProfileControllerBuilder()
	 .withLimits({1.0, 2.0, 10.0})
	 .withOutput(drive)
	 .buildMotionProfileController();



/**
 * A callback function for LLEMU's center button.
 *
 * When this callback is fired, it will toggle line 2 of the LCD text between
 * "I was pressed!" and nothing.
 */
void on_center_button() {
	static bool pressed = false;
	pressed = !pressed;
	if (pressed) {
		pros::lcd::set_text(2, "I was pressed!");
	} else {
		pros::lcd::clear_line(2);
	}
}

/**
 * Runs initialization code. This occurs as soon as the program is started.
 */
void initialize() {
	pros::lcd::initialize();
	pros::lcd::set_text(1, "M A R V I N");

	pros::lcd::register_btn1_cb(on_center_button);


	left_intake.setBrakeMode(AbstractMotor::brakeMode::hold);
	right_intake.setBrakeMode(AbstractMotor::brakeMode::hold);
	drive->setMaxVelocity(50);
}

/**
 * Runs while the robot is in the disabled state of Field Management System or
 * the VEX Competition Switch, following either autonomous or opcontrol. When
 * the robot is enabled, this task will exit.
 */
void disabled() {}

/**
 * Runs after initialize(), and before autonomous when connected to the Field
 * Management System or the VEX Competition Switch. This is intended for
 * competition-specific initialization routines, such as an autonomous selector
 * on the LCD.
 *
 * This task will exit when the robot is enabled and autonomous or opcontrol
 * starts.
 */
void competition_initialize() {}

/**
 * Runs the user autonomous code. This function will be started in its own task
 * with the default priority and stack size whenever the robot is enabled via
 * the Field Management System or the VEX Competition Switch in the autonomous
 * mode. Alternatively, this function may be called in initialize or opcontrol
 * for non-competition testing purposes.
 *
 * If the robot is disabled or communications is lost, the autonomous task
 * will be stopped. Re-enabling the robot will restart the task, not re-start it
 * from where it left off.
 */
void autonomous() {
		left_intake.moveVelocity(100);
		right_intake.moveVelocity(100);
		drive->moveDistance(14_in);
		pros::delay(10);
		drive->moveDistance(7_in);
		pros::delay(10);
		drive->moveDistance(7_in);
		pros::delay(10);
		drive->moveDistance(8_in);
		left_intake.moveVelocity(0);
		right_intake.moveVelocity(0);
		pros::delay(10);
		drive->turnAngle(197_deg);
		drive->moveDistance(22_in);

}

//X buttion to run autonomous
void xbttn() {
	// Run the test autonomous routine if we press the button
	if (runAutoButton.changedToPressed()) {
		drive->setState({0_in, 0_in, 0_deg});
		drive->driveToPoint({1_ft, 1_ft});
		drive->turnToAngle(90_deg);
		drive->turnToPoint({5_ft, 0_ft});
	}
}

//drive function
void chassis_drive() {
	drive->getModel()->tank(master.getAnalog(ControllerAnalog::leftY),
													master.getAnalog(ControllerAnalog::rightY));
	// drive->getModel()->arcade(master.getAnalog(ControllerAnalog::leftY),
	// 						 	         master.getAnalog(ControllerAnalog::leftX));
}

//intake function
void intake_op() {
	if (intakeIN.isPressed()) {
		left_intake.moveVelocity(100);
		right_intake.moveVelocity(100);
	} else if (intakeOUT.isPressed()) {
		left_intake.moveVelocity(-100);
		right_intake.moveVelocity(-100);
	} else {
		left_intake.moveVelocity(0);
		right_intake.moveVelocity(0);
	}
}

//lift function
void lift_op() {
	if (liftUP.isPressed()) {
		armLift.moveVelocity(100);
	} else if (liftDOWN.isPressed()) {
		armLift.moveVelocity(-100);
	} else {
		armLift.moveVelocity(0);
	}
}

//tray function
void tray_op() {
	if (trayBWD.isPressed()) {
		tray.moveVelocity(200);
	} else if (trayFWD.isPressed()) {
		tray.moveVelocity(-200);
	} else {
		tray.moveVelocity(0);
	}
}
/**
 * Runs the operator control code. This function will be started in its own task
 * with the default priority and stack size whenever the robot is enabled via
 * the Field Management System or the VEX Competition Switch in the operator
 * control mode.
 *
 * If no competition control is connected, this function will run immediately
 * following initialize().
 *
 * If the robot is disabled or communications is lost, the
 * operator control task will be stopped. Re-enabling the robot will restart the
 * task, not resume it from where it left off.
 */
void opcontrol() {
		drive->setMaxVelocity(200);
	while (true) {
		xbttn();
		chassis_drive();
		intake_op();
		lift_op();
		tray_op();
		pros::lcd::print(0, "%d %d %d", (pros::lcd::read_buttons() & LCD_BTN_LEFT) >> 2,
		                 (pros::lcd::read_buttons() & LCD_BTN_CENTER) >> 1,
		                 (pros::lcd::read_buttons() & LCD_BTN_RIGHT) >> 0);

		pros::delay(10);
	}
}
